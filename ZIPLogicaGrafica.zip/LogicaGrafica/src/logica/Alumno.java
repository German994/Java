package logica;

import java.util.ArrayList;

public class Alumno {

    private String nombre;
    private String apellido;
    private String genero;
    private String cursos; // Año que cursa (1ro, 2do o 3ro)
    //private ArrayList <favoritas> materiasFavoritas = new ArrayList<>();
    
    public Alumno() {
    }

    public Alumno(String nombre, String apellido, String genero, String cursos) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.genero = genero;
        this.cursos = cursos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getCursos() {
        return cursos;
    }

    public void setCursos(String cursos) {
        this.cursos = cursos;
    }

    @Override
    public String toString() {
        return "Alumno{" + "nombre=" + nombre + ", apellido=" + apellido + ", genero=" + genero + ", cursos=" + cursos + '}';
    }

}
