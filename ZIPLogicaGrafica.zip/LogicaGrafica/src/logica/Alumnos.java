
package logica;

public class Alumnos {
    
}
